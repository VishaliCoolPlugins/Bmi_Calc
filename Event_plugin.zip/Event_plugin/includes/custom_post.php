<?php
function custom_post_type_event() {
	$supports = array(
	'title',
	'editor', 
	'author',
	'thumbnail',
	'excerpt',
	'custom-fields',
	'comments',
	'revisions',
	'post-formats',
	);
	$labels = array(
	'name' => _x('Events', 'plural'),
	'singular_name' => _x('Events', 'singular'),
	'menu_name' => _x('Events', 'admin menu'),
	'name_admin_bar' => _x('Events', 'admin bar'),
	'add_new' => _x('Add Events', 'add event '),
	'add_new_item' => __('Add New event'),
	'new_item' => __('New Event'),
	'edit_item' => __('Edit Event'),
	'view_item' => __('View Event'),
	'all_items' => __('All Event'),
	'search_items' => __('Search Event'),
	'not_found' => __('No Event found.'),
	);
	$args = array(
	'supports' => $supports,
	'labels' => $labels,
	'public' => true,
	'query_var' => true,
	'rewrite' => array('slug' => 'event'),
	'has_archive' => true,
	'hierarchical' => false,
	);
	register_post_type('all-events', $args);
	}
	custom_post_type_event();


// custom taxonomy
function add_custom_taxonomies() {
	register_taxonomy('category', 'all-events', array(
	  
	  'hierarchical' => true,
	  
	  'labels' => array(
		'name' => _x( 'category', 'taxonomy general name' ),
		'singular_name' => _x( 'category', 'taxonomy singular name' ),
		'search_items' =>  __( 'Search Category' ),
		'all_items' => __( 'All Category' ),
		'parent_item' => __( 'Parent Category' ),
		'parent_item_colon' => __( 'Parent Category:' ),
		'edit_item' => __( 'Edit Category' ),
		'update_item' => __( 'Update Category' ),
		'add_new_item' => __( 'Add New Category' ),
		'new_item_name' => __( 'New Category Name' ),
		'menu_name' => __( 'category' ),

	  ),
	  
	  'rewrite' => array(
		'slug' => 'category', 
		'with_front' => false, 
		'hierarchical' => true 
	  ),
	));
}
  add_custom_taxonomies();

//custom Meta-Box
function wporg_add_custom_box() {
	$screens = [ 'all-events' ];
	foreach ( $screens as $screen ) {
		add_meta_box(
			'wporg_box_id',                 
			'Time & Venue:',      
			'wporg_custom_box_html',  
			$screen = 'all-events',
          
		);
	}
}
add_action( 'add_meta_boxes', 'wporg_add_custom_box' );
function wporg_custom_box_html( $post ){
    
    $value = get_post_meta($post->ID, 'event-start-time' , true);
    $value1 = get_post_meta($post->ID, 'event-end-time' , true);
	$value2 = get_post_meta($post->ID, 'event-venue-address' , true);
	$value3 = get_post_meta($post->ID, 'event-venue-city' , true);
	$value4 = get_post_meta($post->ID, 'event-venue-state' , true);
	$value5 = get_post_meta($post->ID, 'event-venue-country' , true);
	$value6 = get_post_meta($post->ID, 'event-venue-map' , true);
    ?>
	<label>Time of an Event:</label><br>
	<label>Start Time:</label>
    <input type="datetime-local" name = "event-start-time" value ="<?php echo $value; ?>" required>
	<label>End Time:</label>
    <input type="datetime-local" name = "event-end-time" value ="<?php echo $value1; ?>"required><br>
	<label>Venue of an Event:</label><br>
	<label>Address:</label>
    <input type= "text" name = "event-venue-address" value ="<?php echo $value2; ?>"required><br>
	<label>City:</label>
    <input type="text" name = "event-venue-city" value ="<?php echo $value3; ?>"required>
	<label>State:</label>
    <input type="text" name = "event-venue-state" value ="<?php echo $value4; ?>">
	<label>Country:</label>
    <input type="text" name = "event-venue-country" value ="<?php echo $value5; ?>">
	<br>
	<label>Map Link:</label>
    <input type="text" name = "event-venue-map" value ="<?php echo $value6; ?>">
	<?php
}
function save_postdata( $post_id ) {
	if ( array_key_exists( 'event-start-time', $_POST ) ) {
		update_post_meta(
			$post_id,
			'event-start-time',
			$_POST['event-start-time']
		);
	}
	if ( array_key_exists( 'event-end-time', $_POST ) ) {
		update_post_meta(
			$post_id,
			'event-end-time',
			$_POST['event-end-time']
		);
	}
	if ( array_key_exists( 'event-venue-address', $_POST ) ) {
		update_post_meta(
			$post_id,
			'event-venue-address',
			$_POST['event-venue-address']
		);
	}
	if ( array_key_exists( 'event-venue-city', $_POST ) ) {
		update_post_meta(
			$post_id,
			'event-venue-city',
			$_POST['event-venue-city']
		);
	}
	if ( array_key_exists( 'event-venue-state', $_POST ) ) {
		update_post_meta(
			$post_id,
			'event-venue-state',
			$_POST['event-venue-state']
		);
	}
	if ( array_key_exists( 'event-venue-country', $_POST ) ) {
		update_post_meta(
			$post_id,
			'event-venue-country',
			$_POST['event-venue-country']
		);
	}
	if ( array_key_exists( 'event-venue-map', $_POST ) ) {
		update_post_meta(
			$post_id,
			'event-venue-map',
			$_POST['event-venue-map']
		);
	}
}
add_action( 'save_post', 'save_postdata' );