<?php
function my_event_shortcode($attr){
  
$attr = shortcode_atts(array(
    'posts_per_page' => 10,
    'category' => '',
    'post_type' => 'all-events',
),$attr);
$limit = $attr['posts_per_page'];
$posts = get_posts($attr);
global $post;
$the_query = new WP_Query( $attr );

if($the_query->have_posts()){
    if(!is_admin()){ 
 ?>
<div class="swiper mySwiper">
  <div class="swiper-wrapper">
    <?php
          while ( $the_query->have_posts() ) {
            global $post_id;
            $the_query->the_post();
            $post_thumbnail_id = get_post_thumbnail_id($post_id);
            $image = wp_get_attachment_image_src( $post_thumbnail_id );
            ob_start();
            ?>
    <div class="swiper-slide">
      <div class="container" id="outerdiv">
        <div class="image" id='leftbox'>
          <image src="<?php echo $image[0];?>">
        </div>
        <div class="content" id='middlebox'>
          <?php
          echo '<h2><strong>'.esc_html(get_the_title()) .'</strong></h2>';
          echo  '<h5><strong>'.str_replace('T', ',',get_post_meta($post->ID, 'event-start-time' , true)).'@'. str_replace('T', ',',get_post_meta($post->ID, 'event-end-time' , true)).'</strong></h5>';
          echo '<strong>'. get_post_meta($post->ID, 'event-venue-address' , true).' ';
          echo get_post_meta($post->ID, 'event-venue-city' , true).' ';
          echo get_post_meta($post->ID, 'event-venue-state' , true).' ';
          echo get_post_meta($post->ID, 'event-venue-country' , true).'</strong><br>';
          echo esc_html(the_content());
          ?>
        </div>
        <div class="map" id='rightbox'>
          <?php
                echo get_post_meta($post->ID, 'event-venue-map' , true);
                ?>
        </div>
      </div>
    </div>
    <?php
        }}
        ?>
  </div>
   <div class="swiper-button-next"></div>
  <div class="swiper-button-prev"></div>
</div>

<?php
      wp_reset_postdata();
      $content = ob_get_clean(); 
    return $content; 
} 
else{
	esc_html_e( 'Sorry, no posts matched your criteria.' );
}}
add_shortcode('event_calendar', 'my_event_shortcode');