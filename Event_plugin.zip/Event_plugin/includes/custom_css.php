<?php
function custom_style(){
    wp_enqueue_style(
    'event_custom_style',
    trailingslashit(CUSTOM_PLUGIN_URL . 'assets/plugin.css')
    );
}
add_action('wp_head' , 'custom_style',1);
