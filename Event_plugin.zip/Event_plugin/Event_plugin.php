<?php
/*
 * Plugin Name:       Event Plugin
 * Description:       Handle the basics with this plugin.
 * Version:           1.10.3
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Me
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://example.com/my-plugin/
 * Text Domain:       Event Plugin
 * Domain Path:       /languages
 */

 /**
 * Register a custom post type called "event".
 *
 * @see get_post_type_labels() for label keys.
 */
define('CUSTOM_PLUGIN_URL',plugin_dir_url(__FILE__));

class custom_plugin{
    
  
    private static $instance;
    public static function get_instance(){
        if(null === self::$instance){
            self::$instance = new self();
        }
        return self::$instance;
    }
    public function __construct(){
        add_action('init', array($this, 'file_load'));
        wp_enqueue_style(
            'event_custom_style',
            CUSTOM_PLUGIN_URL . 'assets/plugin.css',
            );
        wp_enqueue_script(
            'event_custom_script',
            CUSTOM_PLUGIN_URL . 'assets/plugin.js',
            array(
                'jquery',
               ), 
               NULL,
               true
        );
        wp_register_script( 'swiperjs', 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js', null, null, false);
        wp_enqueue_script('swiperjs'); 
        wp_register_style( 'swipercss', 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css');
        wp_enqueue_style('swipercss');
        
    }

    public function file_load(){
        include plugin_dir_path(__FILE__).'includes/custom_post.php';
        include plugin_dir_path(__FILE__).'includes/custom_shortcode.php'; 
    }
}
$plugin = custom_plugin::get_instance();